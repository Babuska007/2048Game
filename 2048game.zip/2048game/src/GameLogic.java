public class GameLogic{
    private final Grid grid;

    public GameLogic(Grid grid){
        this.grid = grid;
    }

    public void moveLeft(){
        for (int row = 0; row < Grid.GRID_SIZE; row++){
            compressRow(row);
            mergeRow(row);
            compressRow(row);
        }
    }

    public void moveRight(){
        for (int row = 0; row < Grid.GRID_SIZE; row++){
            reverseRow(row);
            compressRow(row);
            mergeRow(row);
            compressRow(row);
            reverseRow(row);
        }
    }

    public void moveUp(){
        for (int col = 0; col < Grid.GRID_SIZE; col++){
            compressColumn(col);
            mergeColumn(col);
            compressColumn(col);
        }
    }

    public void moveDown(){
        for (int col = 0; col < Grid.GRID_SIZE; col++){
            reverseColumn(col);
            compressColumn(col);
            mergeColumn(col);
            compressColumn(col);
            reverseColumn(col);
        }
    }

    private void compressRow(int row){
        int[] newRow = new int[Grid.GRID_SIZE];
        int index = 0;
        for (int col = 0; col < Grid.GRID_SIZE; col++){
            if (grid.getGrid()[row][col] != 0) {
                newRow[index++] = grid.getGrid()[row][col];
            }
        }
        grid.getGrid()[row] = newRow;
    }

    private void mergeRow(int row){
        for (int col = 0; col < Grid.GRID_SIZE - 1; col++){
            if (grid.getGrid()[row][col] == grid.getGrid()[row][col + 1] && grid.getGrid()[row][col] != 0) {
                grid.getGrid()[row][col] *= 2;
                grid.getGrid()[row][col + 1] = 0;
            }
        }
    }

    private void reverseRow(int row){
        for (int col = 0; col < Grid.GRID_SIZE / 2; col++){
            int temp = grid.getGrid()[row][col];
            grid.getGrid()[row][col] = grid.getGrid()[row][Grid.GRID_SIZE - col - 1];
            grid.getGrid()[row][Grid.GRID_SIZE - col - 1] = temp;
        }
    }

    private void compressColumn(int col){
        int[] newCol = new int[Grid.GRID_SIZE];
        int index = 0;
        for (int row = 0; row < Grid.GRID_SIZE; row++){
            if (grid.getGrid()[row][col] != 0) {
                newCol[index++] = grid.getGrid()[row][col];
            }
        }
        for (int row = 0; row < Grid.GRID_SIZE; row++){
            grid.getGrid()[row][col] = newCol[row];
        }
    }

    private void mergeColumn(int col){
        for (int row = 0; row < Grid.GRID_SIZE - 1; row++){
            if (grid.getGrid()[row][col] == grid.getGrid()[row + 1][col] && grid.getGrid()[row][col] != 0) {
                grid.getGrid()[row][col] *= 2;
                grid.getGrid()[row + 1][col] = 0;
            }
        }
    }

    private void reverseColumn(int col){
        for (int row = 0; row < Grid.GRID_SIZE / 2; row++){
            int temp = grid.getGrid()[row][col];
            grid.getGrid()[row][col] = grid.getGrid()[Grid.GRID_SIZE - row - 1][col];
            grid.getGrid()[Grid.GRID_SIZE - row - 1][col] = temp;
        }
    }
}
