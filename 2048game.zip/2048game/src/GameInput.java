import java.util.Scanner;

public class GameInput{
    private final Scanner scanner;

    public GameInput(){
        scanner = new Scanner(System.in);
    }

    public String getMove(){
        System.out.print("Move/Quit (WASD/Q): ");
        return scanner.nextLine().toLowerCase();
    }

    public void close(){
        scanner.close();
    }
}
