import java.util.Arrays;

public class Game2048{
    private final Grid grid;
    private final GameLogic gameLogic;
    private final GameInput gameInput;


    public Game2048(){
        grid = new Grid();
        gameLogic = new GameLogic(grid);
        gameInput = new GameInput();
    }

    private void clearConsole(){
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public void runGame(){
        while (!grid.isGameOver()){
            clearConsole();
            grid.printGrid();
            String move = gameInput.getMove();

            int[][] originalGrid = grid.copyGrid();

            switch (move){
                case "a":
                    gameLogic.moveLeft();
                    break;
                case "d":
                    gameLogic.moveRight();
                    break;
                case "w":
                    gameLogic.moveUp();
                    break;
                case "s":
                    gameLogic.moveDown();
                    break;
                case "q":
                    gameInput.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid move. Use W (up), A (left), S (down), D (right), Q(quit).");
                    continue;
            }

            if (!Arrays.deepEquals(originalGrid, grid.getGrid())){
                grid.addRandomTile();
            }

            if (grid.checkWin()){
                grid.printGrid();
                System.out.println("You win!");
                System.exit(0);
            }
        }

        grid.printGrid();
        System.out.println("Game Over!");
        gameInput.close();
    }
}
