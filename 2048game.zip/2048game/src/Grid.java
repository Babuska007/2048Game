import java.util.Arrays;
import java.util.Random;

public class Grid{
    public final int[][] grid;
    public static final int GRID_SIZE = 4;

    public Grid(){
        grid = new int[GRID_SIZE][GRID_SIZE];
        addRandomTile();
        addRandomTile();
    }

    public int[][] getGrid(){
        return grid;
    }

    public void addRandomTile(){
        Random random = new Random();
        int value = random.nextDouble() < 0.9 ? 2 : 4;
        int x, y;
        do{
            x = random.nextInt(GRID_SIZE);
            y = random.nextInt(GRID_SIZE);
        } while (grid[x][y] != 0);
        grid[x][y] = value;
    }

    public boolean checkWin(){
        for (int row = 0; row < GRID_SIZE; row++){
            for (int col = 0; col < GRID_SIZE; col++){
                if (grid[row][col] == 2048){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isGameOver(){
        for (int row = 0; row < GRID_SIZE; row++){
            for (int col = 0; col < GRID_SIZE; col++){
                if (grid[row][col] == 0) return false;
                if (col < GRID_SIZE - 1 && grid[row][col] == grid[row][col + 1]) return false;
                if (row < GRID_SIZE - 1 && grid[row][col] == grid[row + 1][col]) return false;
            }
        }
        return true;
    }

    public void printGrid(){
        for (int row = 0; row < GRID_SIZE; row++){
            for (int col = 0; col < GRID_SIZE; col++){
                System.out.print(grid[row][col] + "\t");
            }
            System.out.println();
        }
    }

    public int[][] copyGrid(){
        int[][] copy = new int[GRID_SIZE][GRID_SIZE];
        for (int i = 0; i < GRID_SIZE; i++) {
            copy[i] = Arrays.copyOf(grid[i], GRID_SIZE);
        }
        return copy;
    }
}
